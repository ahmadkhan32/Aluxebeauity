<?php
/**
 * Checkout Form
 *
 * @package RAWR_Beauty
 */

defined('ABSPATH') || exit;

do_action('woocommerce_before_checkout_form', $checkout);

if (!$checkout->is_registration_enabled() && $checkout->is_registration_required() && !is_user_logged_in()) {
    echo esc_html(apply_filters('woocommerce_checkout_must_be_logged_in_message', __('You must be logged in to checkout.', 'rawr-beauty')));
    return;
}
?>
<div class="rawr-checkout-container" style="max-width: 960px; margin: 0 auto; padding: 40px 0;">
    <h1 class="rawr-title" style="text-align: center; margin-bottom: 30px;"><?php esc_html_e('Secure Checkout', 'rawr-beauty'); ?></h1>
    <form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url(wc_get_checkout_url()); ?>" enctype="multipart/form-data">
        <?php if ($checkout->get_checkout_fields()) : ?>
            <?php do_action('woocommerce_checkout_before_customer_details'); ?>
            <div class="col2-set" id="customer_details">
                <div class="col-1"><?php do_action('woocommerce_checkout_billing'); ?></div>
                <div class="col-2"><?php do_action('woocommerce_checkout_shipping'); ?></div>
            </div>
            <?php do_action('woocommerce_checkout_after_customer_details'); ?>
        <?php endif; ?>

        <h3 id="order_review_heading"><?php esc_html_e('Your Order', 'rawr-beauty'); ?></h3>
        <?php do_action('woocommerce_checkout_before_order_review'); ?>
        <div id="order_review" class="woocommerce-checkout-review-order">
            <?php do_action('woocommerce_checkout_order_review'); ?>
        </div>
        <?php do_action('woocommerce_checkout_after_order_review'); ?>
    </form>
</div>
